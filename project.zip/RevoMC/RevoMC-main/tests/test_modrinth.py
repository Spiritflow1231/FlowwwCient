import hashlib
import io
import json
import tempfile
import unittest
import urllib.parse
import zipfile
from pathlib import Path
from unittest.mock import patch

from core import modrinth


class _FakeResponse:
    def __init__(self, data: bytes):
        self._stream = io.BytesIO(data)
        self.headers = {"Content-Length": str(len(data))}

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return None

    def read(self, size=-1):
        return self._stream.read(size)

    def geturl(self):
        return "https://cdn.modrinth.com/sample.jar"


class ModrinthContentTests(unittest.TestCase):
    def test_rejects_unsafe_archive_paths(self):
        for value in ("../escape", "/absolute", "folder\\file", "C:/escape"):
            with self.subTest(path=value), self.assertRaises(ValueError):
                modrinth._safe_relative_path(value)

    def test_search_uses_modrinth_project_type_and_fabric_facets(self):
        response = {"hits": [{"project_id": "test"}]}
        with patch("core.modrinth._request_json", return_value=response) as request:
            projects = modrinth.search_projects("mods", "sodium", "1.21.1", "fabric")
        self.assertEqual(projects, response["hits"])
        params = urllib.parse.parse_qs(urllib.parse.urlsplit(request.call_args.args[0]).query)
        facets = json.loads(params["facets"][0])
        self.assertEqual(
            facets,
            [["project_type:mod"], ["versions:1.21.1"], ["categories:fabric"]],
        )

    def test_search_routes_each_category_to_its_modrinth_project_type(self):
        cases = (
            ("mods", "mod", "fabric", True),
            ("resourcepacks", "resourcepack", "fabric", False),
            ("modpacks", "modpack", "fabric", True),
            ("datapacks", "datapack", "vanilla", False),
            ("shaderpacks", "shader", "fabric", False),
        )
        for category, project_type, loader, uses_fabric_facet in cases:
            with self.subTest(category=category):
                with patch(
                    "core.modrinth._request_json",
                    return_value={"hits": [{"project_id": category}]},
                ) as request:
                    projects = modrinth.search_projects(
                        category, "test query", "1.21.1", loader
                    )

                self.assertEqual(projects, [{"project_id": category}])
                params = urllib.parse.parse_qs(
                    urllib.parse.urlsplit(request.call_args.args[0]).query
                )
                facets = json.loads(params["facets"][0])
                self.assertEqual(facets[0], [f"project_type:{project_type}"])
                self.assertIn(["versions:1.21.1"], facets)
                self.assertEqual(
                    ["categories:fabric"] in facets,
                    uses_fabric_facet,
                )
                self.assertEqual(params["query"], ["test query"])

    def test_version_query_filters_game_version_and_loader(self):
        with patch(
            "core.modrinth._request_json",
            return_value=[
                {"game_versions": ["1.21.1"], "loaders": ["fabric"]},
                {"game_versions": ["1.21.1"], "loaders": ["forge"]},
                {"game_versions": ["1.20.1"], "loaders": ["fabric"]},
            ],
        ):
            versions = modrinth.compatible_versions("project", "mods", "1.21.1", "fabric")
        self.assertEqual(len(versions), 1)
        self.assertEqual(versions[0]["loaders"], ["fabric"])

    def test_resolves_required_dependencies_recursively_and_warns_on_incompatible(self):
        root = {
            "project_id": "root",
            "name": "Root Mod",
            "dependencies": [
                {"project_id": "first", "dependency_type": "required"},
                {"project_id": "blocked", "dependency_type": "incompatible"},
            ],
        }
        first = {
            "id": "first-version",
            "project_id": "first",
            "dependencies": [
                {"project_id": "second", "dependency_type": "required"},
            ],
        }
        second = {"id": "second-version", "project_id": "second"}

        def versions(project_id, category, game_version, loader):
            self.assertEqual((category, game_version, loader), ("mods", "1.21.1", "fabric"))
            return [{"first": first, "second": second}[project_id]]

        with (
            patch("core.modrinth.compatible_versions", side_effect=versions),
            patch(
                "core.modrinth._request_json",
                side_effect=lambda url: {"title": url.rsplit("/", 1)[-1]},
            ),
        ):
            resolved, warnings = modrinth.resolve_required_mod_dependencies(
                root, "1.21.1", "fabric"
            )

        self.assertEqual([item[0] for item in resolved], ["second", "first"])
        self.assertIn("blocked", warnings[0])

    def test_skips_dependencies_already_installed(self):
        root = {
            "project_id": "root",
            "dependencies": [
                {"project_id": "already-there", "dependency_type": "required"},
            ],
        }
        with (
            patch("core.modrinth.compatible_versions") as versions,
            patch("core.modrinth._request_json") as request,
        ):
            resolved, warnings = modrinth.resolve_required_mod_dependencies(
                root,
                "1.21.1",
                "fabric",
                installed_project_ids={"already-there"},
            )

        self.assertEqual(resolved, [])
        self.assertEqual(warnings, [])
        versions.assert_not_called()
        request.assert_not_called()

    def test_imports_fabric_modpack_overrides_into_fresh_instance(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            archive_path = root / "pack.mrpack"
            destination = root / "instances" / "profile"
            manifest = {
                "formatVersion": 1,
                "name": "Test Pack",
                "dependencies": {
                    "minecraft": "1.21.1",
                    "fabric-loader": "0.16.10",
                },
                "files": [],
            }
            with zipfile.ZipFile(archive_path, "w") as archive:
                archive.writestr("modrinth.index.json", json.dumps(manifest))
                archive.writestr("overrides/config/example.txt", "profile config")

            imported = modrinth.install_modpack(archive_path, destination)

            self.assertEqual(imported["type"], "fabric")
            self.assertEqual(imported["fabric_loader_version"], "0.16.10")
            self.assertEqual(
                (destination / "config" / "example.txt").read_text(),
                "profile config",
            )

    def test_rejects_unsupported_modpack_loader_without_creating_instance(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            archive_path = root / "pack.mrpack"
            destination = root / "instances" / "profile"
            manifest = {
                "formatVersion": 1,
                "dependencies": {
                    "minecraft": "1.20.1",
                    "forge": "47.2.0",
                },
                "files": [],
            }
            with zipfile.ZipFile(archive_path, "w") as archive:
                archive.writestr("modrinth.index.json", json.dumps(manifest))

            with self.assertRaisesRegex(RuntimeError, "vanilla and Fabric"):
                modrinth.install_modpack(archive_path, destination)
            self.assertFalse(destination.exists())

    def test_download_verifies_hash_and_does_not_overwrite(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            payload = io.BytesIO()
            with zipfile.ZipFile(payload, "w") as archive:
                archive.writestr("fabric.mod.json", "{}")
            data = payload.getvalue()
            version = {
                "files": [{
                    "filename": "sample.jar",
                    "url": "https://cdn.modrinth.com/sample.jar",
                    "primary": True,
                    "hashes": {"sha1": hashlib.sha1(data).hexdigest()},
                }],
            }
            with patch("core.modrinth.urllib.request.urlopen", return_value=_FakeResponse(data)):
                installed = modrinth.download_project_file(version, "mods", root)
            self.assertEqual(installed.read_bytes(), data)

            with patch("core.modrinth.urllib.request.urlopen") as open_url:
                with self.assertRaises(FileExistsError):
                    modrinth.download_project_file(version, "mods", root)
                open_url.assert_not_called()

    def test_rejects_download_hash_mismatch(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            payload = io.BytesIO()
            with zipfile.ZipFile(payload, "w") as archive:
                archive.writestr("fabric.mod.json", "{}")
            data = payload.getvalue()
            version = {
                "files": [{
                    "filename": "sample.jar",
                    "url": "https://cdn.modrinth.com/sample.jar",
                    "hashes": {"sha1": "0" * 40},
                }],
            }
            with patch("core.modrinth.urllib.request.urlopen", return_value=_FakeResponse(data)):
                with self.assertRaisesRegex(RuntimeError, "integrity check"):
                    modrinth.download_project_file(version, "mods", root)
            self.assertFalse((root / "sample.jar").exists())

    def test_rejects_invalid_downloaded_resourcepack_and_cleans_file(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            data = b"not a resource-pack archive"
            version = {
                "files": [{
                    "filename": "sample.zip",
                    "url": "https://cdn.modrinth.com/sample.zip",
                    "primary": True,
                }],
            }
            with patch(
                "core.modrinth.urllib.request.urlopen",
                return_value=_FakeResponse(data),
            ):
                with self.assertRaisesRegex(ValueError, "valid ZIP/JAR"):
                    modrinth.download_project_file(version, "resourcepacks", root)
            self.assertFalse((root / "sample.zip").exists())


if __name__ == "__main__":
    unittest.main()
