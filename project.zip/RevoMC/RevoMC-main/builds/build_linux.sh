#!/bin/bash
set -euo pipefail

echo "Setting up local FlowwwClient build environment for Linux..."

PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$PROJECT_ROOT"

if ! command -v python3.12 >/dev/null 2>&1; then
    echo "Error: Python 3.12 is required for this PyInstaller build." >&2
    exit 1
fi

# Create a virtual environment if it does not exist.
if [ ! -x ".venv/bin/python" ]; then
    echo "Creating Python 3.12 virtual environment..."
    python3.12 -m venv .venv
fi

PYTHON=".venv/bin/python"

echo "Installing requirements..."
"$PYTHON" -m pip install --upgrade pip
"$PYTHON" -m pip install -r requirements.txt requests pyinstaller

if ! "$PYTHON" -c "import tkinter" >/dev/null 2>&1; then
    echo "Error: Tkinter is required to build FlowwwClient." >&2
    echo "Install your OS package (Ubuntu/Debian: python3-tk; Fedora: python3-tkinter), then recreate .venv." >&2
    exit 1
fi

echo "Running syntax checks and tests..."
"$PYTHON" -m compileall -q main.py core ui tests
"$PYTHON" -m unittest discover -s tests -v

echo "Building Linux application..."
"$PYTHON" -m PyInstaller revomc.spec --clean --noconfirm --distpath dist/linux --workpath build/pyinstaller-linux

APP="dist/linux/FlowwwClient/FlowwwClient"
if [ ! -x "$APP" ]; then
    echo "Error: PyInstaller did not create the executable at $APP." >&2
    exit 1
fi

echo "Running smoke test..."
"$APP" --smoke-test

echo ""
echo "Build complete and validated: $APP"
