@echo off
setlocal
echo Setting up local FlowwwClient build environment...

:: Ensure we are in the project directory (one level up from builds folder).
cd /d "%~dp0\.."

:: PyInstaller needs a supported Python installation with its shared runtime.
if not exist ".venv\Scripts\python.exe" (
    echo Creating virtual environment...
    py -3.12 -m venv .venv
    if errorlevel 1 goto :failed
)

set "PYTHON=.venv\Scripts\python.exe"

echo Installing requirements...
%PYTHON% -m pip install --upgrade pip
if errorlevel 1 goto :failed
%PYTHON% -m pip install -r requirements.txt requests pyinstaller
if errorlevel 1 goto :failed

echo Running syntax checks and tests...
%PYTHON% -m compileall -q main.py core ui tests
if errorlevel 1 goto :failed
%PYTHON% -m unittest discover -s tests -v
if errorlevel 1 goto :failed

echo Building the Windows executable...
%PYTHON% -m PyInstaller revomc.spec --clean --noconfirm --distpath dist/release --workpath build/pyinstaller-release
if errorlevel 1 goto :failed
if not exist "dist\release\FlowwwClient.exe" (
    echo Error: PyInstaller finished without creating dist\release\FlowwwClient.exe.
    goto :failed
)

echo Running smoke test...
dist\release\FlowwwClient.exe --smoke-test
if errorlevel 1 goto :failed

echo.
echo Build complete and validated: dist\release\FlowwwClient.exe
pause
exit /b 0

:failed
echo.
echo Build failed. Review the error output above.
pause
exit /b 1
